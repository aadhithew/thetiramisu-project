document.addEventListener("DOMContentLoaded", function () {
  var TP = window.TP || { products: {}, delivery: [] };

  // Mobile menu
  var toggle = document.querySelector(".menu-toggle");
  var nav = document.getElementById("navigation");
  if (toggle && nav) {
    toggle.addEventListener("click", function () {
      var open = nav.classList.toggle("open");
      toggle.setAttribute("aria-expanded", open ? "true" : "false");
    });
  }

  // Footer year
  var year = document.getElementById("year");
  if (year) year.textContent = new Date().getFullYear();

  // Product dialog
  var dialog = document.getElementById("product-dialog");
  function openProduct(key) {
    var p = TP.products[key];
    if (!p || !dialog) return;
    document.getElementById("dialog-title").textContent = p.title;
    document.getElementById("dialog-description").textContent = p.description;
    document.getElementById("dialog-note").textContent = p.note || "";
    var dl = document.getElementById("confirmed-product-details");
    dl.innerHTML = "";
    Object.keys(p.details || {}).forEach(function (k) {
      var dt = document.createElement("dt"); dt.textContent = k;
      var dd = document.createElement("dd"); dd.textContent = p.details[k];
      dl.appendChild(dt); dl.appendChild(dd);
    });
    document.getElementById("dialog-order").href = TP.uber;
    dialog.showModal();
  }
  document.querySelectorAll("[data-product]").forEach(function (el) {
    el.addEventListener("click", function () { openProduct(el.getAttribute("data-product")); });
  });

  // Dialog close buttons + backdrop click
  document.querySelectorAll("dialog").forEach(function (d) {
    var close = d.querySelector(".dialog-close");
    if (close) close.addEventListener("click", function () { d.close(); });
    d.addEventListener("click", function (e) { if (e.target === d) d.close(); });
  });

  // Privacy dialog
  var pBtn = document.getElementById("privacy-open");
  var pDlg = document.getElementById("privacy-dialog");
  if (pBtn && pDlg) pBtn.addEventListener("click", function () { pDlg.showModal(); });

  // Delivery grid
  var grid = document.getElementById("delivery-grid");
  if (grid) {
    TP.delivery.forEach(function (d) {
      var a = document.createElement("article");
      a.innerHTML = "<h3></h3><p></p>";
      a.querySelector("h3").textContent = d.title;
      a.querySelector("p").textContent = d.text;
      grid.appendChild(a);
    });
  }

  // Copy helper
  function copyText(text, statusEl, okMsg) {
    function done(ok) { statusEl.textContent = ok ? okMsg : "Please select and copy the text below."; }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(function () { done(true); }, function () { done(false); });
    } else { done(false); }
  }

  // Order enquiry
  var form = document.getElementById("order-enquiry");
  if (form) {
    var dateInput = document.getElementById("order-date");
    if (dateInput) dateInput.min = new Date().toISOString().slice(0, 10);
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var key = form.product.value;
      var name = TP.products[key] ? TP.products[key].title : key;
      var lines = [
        "Hello The Tiramisu Project! I'd like to enquire about an order:",
        "• Tiramisu: " + name,
        "• Quantity: " + form.quantity.value,
        "• Preferred date: " + form.date.value,
        "• Fulfilment: " + form.method.value
      ];
      if (form.notes.value.trim()) lines.push("• Notes: " + form.notes.value.trim());
      lines.push("Please confirm availability, price and fulfilment. Thank you!");
      var text = lines.join("\n");
      document.getElementById("enquiry-text").value = text;
      document.getElementById("enquiry-result").hidden = false;
      copyText(text, document.getElementById("enquiry-status"), "Copied. Now send it on Instagram.");
    });
  }
});
