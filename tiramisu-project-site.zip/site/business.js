// Sample business data. Replace before launch.
window.TP = {
  uber: "https://www.ubereats.com/lk/store/the-tiramisu-project-pannipitiya/k6rlP8PPRKifwkRRKn6V2Q",
  instagram: "https://www.instagram.com/thetiramisuproject/",
  products: {
    "classic": {
      title: "Classic Tiramisu",
      description: "Coffee-soaked layers, mascarpone cream and a dusting of cocoa.",
      note: "The signature of the collection.",
      details: { "Flavour notes": "Coffee, cocoa, cream", "Availability": "Confirm with the team" }
    },
    "strawberry": {
      title: "Strawberry Tiramisu",
      description: "Our coffee-and-cream love story with the fresh, tangy sweetness of strawberries.",
      note: "Seasonal fruit may vary.",
      details: { "Flavour notes": "Strawberry, cream", "Availability": "Confirm with the team" }
    },
    "matcha": {
      title: "Matcha Tiramisu",
      description: "Earthy green tea and soft cream, imagined as a delicate alternative to the classic.",
      note: "Sample flavour idea.",
      details: { "Flavour notes": "Green tea, cream", "Availability": "Sample flavour" }
    },
    "mango": {
      title: "Mango Tiramisu",
      description: "A bright tropical variation with mango and creamy layers.",
      note: "Sample flavour idea.",
      details: { "Flavour notes": "Mango, cream", "Availability": "Sample flavour" }
    },
    "chocolate-orange": {
      title: "Chocolate & Orange Tiramisu",
      description: "Deep chocolate notes with a bright citrus finish.",
      note: "Sample flavour idea.",
      details: { "Flavour notes": "Chocolate, orange", "Availability": "Sample flavour" }
    },
    "raspberry-lavender": {
      title: "Raspberry & Lavender Tiramisu",
      description: "A floral and fruity variation with raspberry and lavender.",
      note: "Sample flavour idea.",
      details: { "Flavour notes": "Raspberry, lavender", "Availability": "Sample flavour" }
    }
  },
  delivery: [
    { title: "Delivery", text: "Check coverage, fees and delivery times for your address on Uber Eats." },
    { title: "Collection", text: "Message the team to arrange pickup in Pannipitiya." },
    { title: "Notice", text: "Celebration and larger orders may need advance notice. Confirm with the team." }
  ]
};
