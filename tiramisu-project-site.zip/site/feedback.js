document.addEventListener("DOMContentLoaded", function () {
  var form = document.getElementById("feedback-form");
  if (!form) return;
  form.addEventListener("submit", function (e) {
    e.preventDefault();
    var rating = form.querySelector('input[name="rating"]:checked');
    var lines = [
      "Feedback for The Tiramisu Project",
      "Rating: " + (rating ? rating.value : "-") + "/5"
    ];
    if (form.name.value.trim()) lines.push("From: " + form.name.value.trim());
    lines.push("", form.message.value.trim());
    var text = lines.join("\n");
    document.getElementById("feedback-preview").value = text;
    document.getElementById("feedback-result").hidden = false;
    var status = document.getElementById("feedback-status");
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(
        function () { status.textContent = "Copied. Paste it into an Instagram message to our team."; },
        function () { status.textContent = "Please select and copy the message below."; }
      );
    } else {
      status.textContent = "Please select and copy the message below.";
    }
  });
});
